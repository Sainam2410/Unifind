/* ==========================================================================
   server.js — จุดเริ่มต้นของระบบ UniFind
   หน้าที่:
   1) เปิดเซิร์ฟเวอร์ Express ที่พอร์ต 3000
   2) โหลดฐานข้อมูล (ไฟล์ data/db.json — สร้างให้อัตโนมัติครั้งแรก)
   3) ผูกเส้นทาง API ทั้งหมด (/api/...)
   4) เสิร์ฟหน้าเว็บจากโฟลเดอร์ frontend
   วิธีรัน:  npm install  แล้ว  npm start  จากนั้นเปิด http://localhost:3000
   ========================================================================== */
const express = require('express');
const path = require('path');
const { PORT } = require('./backend/config');
const db = require('./backend/db');

db.load();

const { attachUser } = require('./backend/auth');
const app = express();

app.use(express.json({ limit: '4mb' })); // รูปภาพถูกย่อฝั่งเบราว์เซอร์แล้ว จึงไม่ใหญ่มาก
app.use(attachUser); // อ่าน token แล้วใส่ req.user ให้ทุกคำขอ

app.use('/api', require('./backend/routes/publicRoutes'));
app.use('/api/auth', require('./backend/routes/authRoutes'));
app.use('/api/items', require('./backend/routes/itemRoutes'));
app.use('/api/claims', require('./backend/routes/claimRoutes'));
app.use('/api/admin', require('./backend/routes/adminRoutes'));
app.use('/api', (req, res) => res.status(404).json({ message: 'ไม่พบ API ที่เรียกใช้' }));

app.use(express.static(path.join(__dirname, 'frontend')));

// ตัวจัดการข้อผิดพลาดกลาง
app.use((err, req, res, next) => {
  if (err.type === 'entity.too.large') return res.status(413).json({ message: 'ไฟล์ที่ส่งมามีขนาดใหญ่เกินไป' });
  if (err.type === 'entity.parse.failed') return res.status(400).json({ message: 'รูปแบบข้อมูลไม่ถูกต้อง' });
  console.error(err);
  res.status(500).json({ message: 'เกิดข้อผิดพลาดภายในระบบ' });
});

app.listen(PORT, () => {
  console.log('\n  🔎 UniFind พร้อมใช้งานแล้ว');
  console.log(`  เปิดเบราว์เซอร์ไปที่  http://localhost:${PORT}\n`);
  console.log('  บัญชีทดลอง');
  console.log('   ผู้ดูแลระบบ : admin@unifind.ac.th    / admin1234');
  console.log('   ผู้ใช้ทั่วไป : somchai@student.ac.th / demo1234\n');
});
