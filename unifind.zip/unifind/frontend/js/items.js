/* ==========================================================================
   frontend/js/items.js — สคริปต์หน้าค้นหา
   หน้าที่: อ่านค่ากรองจาก URL, เรียก /api/items ตามตัวกรอง (หน่วงเวลาเล็กน้อยตอนพิมพ์),
            แสดงผลเป็นการ์ดพร้อมแบ่งหน้า และอัปเดต URL ให้แชร์ลิงก์ได้
   ========================================================================== */
(async () => {
  if (!(await boot())) return;

  const state = {
    search: qs('search') || '', type: qs('type') || '', category: qs('category') || '',
    status: qs('status') || '', location: qs('location') || '', from: qs('from') || '', to: qs('to') || '',
    page: Number(qs('page')) || 1,
  };

  try {
    const { categories } = await API.get('/api/categories');
    $('#fCategory').innerHTML += categories.map((c) => `<option value="${c.id}">${esc(c.icon)} ${esc(c.name)}</option>`).join('');
  } catch { /* ใช้ตัวกรองอื่นต่อได้ */ }

  // ใส่ค่าเริ่มต้นลงช่องกรอก
  $('#fSearch').value = state.search;
  $('#fCategory').value = state.category;
  $('#fStatus').value = state.status;
  $('#fLocation').value = state.location;
  $('#fFrom').value = state.from;
  $('#fTo').value = state.to;
  const markType = () => $$('#fType button').forEach((b) => b.classList.toggle('on', b.dataset.v === state.type));
  markType();

  let timer;
  let seq = 0;
  async function load() {
    const my = ++seq;
    const p = new URLSearchParams();
    Object.entries(state).forEach(([k, v]) => { if (v && !(k === 'page' && v === 1)) p.set(k, v); });
    history.replaceState(null, '', p.toString() ? '?' + p : location.pathname);

    $('#list').innerHTML = loadingHtml();
    $('#list').style.display = 'block';
    try {
      const r = await API.get('/api/items?' + p);
      if (my !== seq) return; // มีคำค้นใหม่กว่าแล้ว
      $('#count').innerHTML = `พบ <b>${r.total}</b> รายการ`;
      if (!r.items.length) {
        $('#list').innerHTML = emptyBox('🕵️', 'ไม่พบรายการที่ตรงกับเงื่อนไข', 'ลองเปลี่ยนคำค้นหาหรือล้างตัวกรอง');
      } else {
        $('#list').style.display = '';
        $('#list').innerHTML = r.items.map(itemCard).join('');
      }
      state.page = r.page;
      renderPager($('#pager'), r.page, r.pages, (n) => { state.page = n; load(); window.scrollTo({ top: 0, behavior: 'smooth' }); });
    } catch (e) {
      $('#list').innerHTML = emptyBox('⚠️', 'โหลดข้อมูลไม่สำเร็จ', e.message);
    }
  }

  const change = (key, el, delay = 0) => el.addEventListener(delay ? 'input' : 'change', () => {
    state[key] = el.value.trim();
    state.page = 1;
    clearTimeout(timer);
    timer = setTimeout(load, delay);
  });
  change('search', $('#fSearch'), 300);
  change('location', $('#fLocation'), 300);
  change('category', $('#fCategory'));
  change('status', $('#fStatus'));
  change('from', $('#fFrom'));
  change('to', $('#fTo'));

  $('#fType').addEventListener('click', (e) => {
    const b = e.target.closest('button');
    if (!b) return;
    state.type = b.dataset.v;
    state.page = 1;
    markType();
    load();
  });

  $('#fClear').addEventListener('click', () => {
    Object.assign(state, { search: '', type: '', category: '', status: '', location: '', from: '', to: '', page: 1 });
    ['#fSearch', '#fCategory', '#fStatus', '#fLocation', '#fFrom', '#fTo'].forEach((s) => { $(s).value = ''; });
    markType();
    load();
  });

  load();
})();
