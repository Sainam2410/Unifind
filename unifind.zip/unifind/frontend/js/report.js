/* ==========================================================================
   frontend/js/report.js — สคริปต์ฟอร์มแจ้งของหาย/พบของ
   หน้าที่: โหลดหมวดหมู่, ปรับข้อความตามประเภท, ย่อรูปก่อนส่ง,
            บันทึกรายการใหม่ (POST) หรือแก้ไขรายการเดิม (PUT เมื่อมี ?edit=)
   ========================================================================== */
(async () => {
  if (!(await boot({ auth: 'user' }))) return;

  const form = $('#form');
  const editId = qs('edit');
  let image; // undefined = ไม่เปลี่ยนรูป, null = ลบรูป, string = รูปใหม่

  const { categories } = await API.get('/api/categories');
  form.categoryId.innerHTML = '<option value="">เลือกหมวดหมู่</option>' + categories.map((c) => `<option value="${c.id}">${esc(c.icon)} ${esc(c.name)}</option>`).join('');
  form.date.max = todayStr();
  form.date.value = todayStr();
  form.contact.value = Auth.user.phone || Auth.user.email;

  function applyType() {
    const t = form.type.value;
    const lost = t === 'lost';
    $('#dateLabel').innerHTML = (lost ? 'วันที่ทำหาย' : 'วันที่พบ') + ' <span class="req">*</span>';
    $('#locLabel').innerHTML = (lost ? 'สถานที่ที่คาดว่าทำหาย' : 'สถานที่ที่พบ') + ' <span class="req">*</span>';
    if (!editId) {
      $('#pageTitle').textContent = lost ? '📝 แจ้งของหาย' : '🎁 แจ้งพบของ';
      $('#pageSub').textContent = lost ? 'บอกรายละเอียดสิ่งที่หายไป เพื่อให้ผู้พบติดต่อกลับได้' : 'บอกรายละเอียดสิ่งที่พบ เพื่อให้เจ้าของมาติดต่อรับคืนได้';
    }
  }
  $$('input[name=type]').forEach((r) => r.addEventListener('change', applyType));

  function showPreview(src) {
    $('#previewImg').src = src;
    $('#preview').classList.remove('hidden');
    $('#upload').classList.add('hidden');
  }
  function clearPreview() {
    $('#preview').classList.add('hidden');
    $('#upload').classList.remove('hidden');
    $('#file').value = '';
  }

  $('#upload').addEventListener('click', () => $('#file').click());
  $('#file').addEventListener('change', async (e) => {
    const f = e.target.files[0];
    if (!f) return;
    try {
      image = await resizeImage(f);
      showPreview(image);
    } catch (ex) { toast(ex.message, 'err'); e.target.value = ''; }
  });
  $('#rmImg').addEventListener('click', () => { image = editId ? null : undefined; clearPreview(); });

  // โหมดแก้ไข: โหลดข้อมูลเดิมมาใส่ฟอร์ม
  if (editId) {
    $('#pageTitle').textContent = '✏️ แก้ไขรายการ';
    $('#pageSub').textContent = 'ปรับปรุงข้อมูลให้ถูกต้องและเป็นปัจจุบัน';
    $('#typePick').classList.add('hidden');
    try {
      const { item } = await API.get('/api/items/' + encodeURIComponent(editId));
      if (!item.canManage) throw new Error('คุณไม่มีสิทธิ์แก้ไขรายการนี้');
      form.type.value = item.type;
      form.title.value = item.title;
      form.categoryId.value = item.categoryId;
      form.date.value = item.date;
      form.location.value = item.location;
      form.description.value = item.description || '';
      form.contact.value = item.contact || '';
      if (item.imageUrl) showPreview(item.imageUrl);
    } catch (e) {
      $('main .card').innerHTML = emptyBox('😕', 'แก้ไขรายการไม่ได้', e.message);
      return;
    }
  } else {
    const t = qs('type') === 'found' ? 'found' : 'lost';
    form.querySelector(`input[name=type][value=${t}]`).checked = true;
  }
  applyType();

  form.addEventListener('submit', async (e) => {
    e.preventDefault();
    const err = $('#err');
    err.classList.add('hidden');
    const body = {
      type: form.type.value, title: form.title.value, categoryId: form.categoryId.value,
      date: form.date.value, location: form.location.value, description: form.description.value, contact: form.contact.value,
    };
    if (image !== undefined) body.image = image;
    const btn = $('#submitBtn');
    btn.disabled = true;
    btn.textContent = 'กำลังบันทึก...';
    try {
      const { item } = editId ? await API.put('/api/items/' + editId, body) : await API.post('/api/items', body);
      toast(editId ? 'บันทึกการแก้ไขแล้ว' : 'แจ้งรายการเรียบร้อยแล้ว');
      location.href = 'item-detail.html?id=' + item.id;
    } catch (ex) {
      err.textContent = ex.message;
      err.classList.remove('hidden');
      err.scrollIntoView({ behavior: 'smooth', block: 'center' });
      btn.disabled = false;
      btn.textContent = 'บันทึกรายการ';
    }
  });
})();
