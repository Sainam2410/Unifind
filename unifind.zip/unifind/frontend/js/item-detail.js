/* ==========================================================================
   frontend/js/item-detail.js — สคริปต์หน้ารายละเอียดรายการ
   หน้าที่: โหลดรายการ, แสดงข้อมูล, ส่งคำขอรับคืน (รายการ "พบของ"),
            และปุ่มจัดการ: แก้ไข / เปลี่ยนสถานะ / ลบ (เฉพาะเจ้าของหรือแอดมิน)
   ========================================================================== */
(async () => {
  if (!(await boot())) return;
  const box = $('#detail');
  const id = qs('id');
  if (!id) { box.innerHTML = emptyBox('❓', 'ไม่พบรายการ', 'ลิงก์ไม่ถูกต้อง'); return; }

  async function load() {
    box.innerHTML = loadingHtml();
    try {
      const { item } = await API.get('/api/items/' + encodeURIComponent(id));
      render(item);
    } catch (e) {
      box.innerHTML = emptyBox('😕', 'ไม่พบรายการนี้', e.message);
    }
  }

  function claimSection(i) {
    const next = encodeURIComponent('item-detail.html?id=' + i.id);
    if (i.type === 'lost') {
      return `<div class="notice info">💡 หากคุณพบสิ่งของนี้ กรุณาติดต่อผู้แจ้งตามข้อมูลติดต่อด้านบน</div>`;
    }
    if (i.status === 'returned') return `<div class="notice ok">✅ สิ่งของชิ้นนี้ได้ส่งคืนเจ้าของเรียบร้อยแล้ว</div>`;
    if (!Auth.user) {
      return `<div class="notice info">เป็นเจ้าของสิ่งของนี้? <a href="login.html?next=${next}"><b>เข้าสู่ระบบ</b></a> เพื่อส่งคำขอรับคืน</div>`;
    }
    if (i.isOwner) {
      return `<div class="notice info">📋 คุณเป็นผู้แจ้งรายการนี้ — ดูและตรวจสอบคำขอรับคืนได้ที่ <a href="my.html?tab=received"><b>คำขอที่ส่งถึงฉัน</b></a>${i.claimCount ? ` (มี ${i.claimCount} คำขอ)` : ''}</div>`;
    }
    if (i.myClaim) {
      const c = i.myClaim;
      return `<div class="notice ${c.status === 'approved' ? 'ok' : c.status === 'rejected' ? 'bad' : 'warn'}">
        คำขอรับคืนของคุณ: ${badge(CLAIM_STATUS, c.status)} <span class="muted">ส่งเมื่อ ${fmtDateTime(c.createdAt)}</span>
        ${c.note ? `<br>หมายเหตุจากผู้ตรวจสอบ: ${esc(c.note)}` : ''}</div>`;
    }
    return `<div class="card claim-box">
      <h2>📨 ส่งคำขอรับคืน</h2>
      <p class="muted" style="margin-bottom:16px">อธิบายลักษณะเฉพาะของสิ่งของที่มีเพียงเจ้าของที่รู้ เพื่อให้ผู้ตรวจสอบยืนยันความเป็นเจ้าของ</p>
      <div class="form-error hidden" id="claimErr"></div>
      <form id="claimForm">
        <div class="field"><label>รายละเอียดยืนยันความเป็นเจ้าของ <span class="req">*</span></label>
          <textarea name="proof" required minlength="10" maxlength="1000" placeholder="เช่น สิ่งของที่อยู่ภายใน ตำหนิ สติกเกอร์ รหัส หรือวันเวลาที่ทำหาย"></textarea></div>
        <div class="field"><label>ช่องทางติดต่อกลับ <span class="req">*</span></label>
          <input type="text" name="contact" required maxlength="100" value="${esc(Auth.user.phone || Auth.user.email)}" placeholder="เบอร์โทร หรือ LINE ID"></div>
        <button class="btn btn-primary" type="submit">ส่งคำขอรับคืน</button>
      </form></div>`;
  }

  function render(i) {
    document.title = i.title + ' - UniFind';
    const media = i.imageUrl
      ? `<img src="${i.imageUrl}" alt="${esc(i.title)}">`
      : `<div class="detail-ph">${esc(i.categoryIcon)}<small>ไม่มีรูปภาพประกอบ</small></div>`;
    const next = encodeURIComponent('item-detail.html?id=' + i.id);
    const contact = Auth.user
      ? (i.contact ? esc(i.contact) : '<span class="muted">ผู้แจ้งไม่ได้ระบุ</span>')
      : `<a href="login.html?next=${next}">เข้าสู่ระบบ</a> เพื่อดูข้อมูลติดต่อ`;

    let manage = '';
    if (i.canManage) {
      manage = `<div class="btn-row" style="margin-top:18px">
        <a class="btn btn-ghost btn-sm" href="report.html?edit=${i.id}">✏️ แก้ไข</a>
        ${i.status === 'returned'
          ? '<button class="btn btn-ghost btn-sm" id="reopenBtn">↩️ เปิดรายการอีกครั้ง</button>'
          : '<button class="btn btn-ok btn-sm" id="returnBtn">✅ ทำเครื่องหมายว่าส่งคืนแล้ว</button>'}
        <button class="btn btn-danger btn-sm" id="delBtn">🗑️ ลบรายการ</button></div>`;
    }

    box.innerHTML = `
      <div class="detail">
        <div class="detail-media">${media}</div>
        <div class="detail-info">
          <div class="badges"><span class="badge ${TYPE[i.type].cls}">${TYPE[i.type].icon} ${TYPE[i.type].text}</span>${badge(STATUS, i.status)}</div>
          <h1>${esc(i.title)}</h1>
          <dl class="info-list">
            <div class="info-row"><dt>หมวดหมู่</dt><dd>${esc(i.categoryIcon)} ${esc(i.categoryName)}</dd></div>
            <div class="info-row"><dt>สถานที่</dt><dd>📍 ${esc(i.location)}</dd></div>
            <div class="info-row"><dt>${i.type === 'lost' ? 'วันที่ทำหาย' : 'วันที่พบ'}</dt><dd>📅 ${fmtDate(i.date)}</dd></div>
            <div class="info-row"><dt>ผู้แจ้ง</dt><dd>👤 ${esc(i.reporterName)}</dd></div>
            <div class="info-row"><dt>ช่องทางติดต่อ</dt><dd>☎️ ${contact}</dd></div>
            <div class="info-row"><dt>แจ้งเมื่อ</dt><dd>${fmtDateTime(i.createdAt)}</dd></div>
          </dl>
          ${i.description ? `<div class="desc">${esc(i.description)}</div>` : ''}
          ${manage}
        </div>
      </div>
      ${claimSection(i)}`;

    $('#returnBtn')?.addEventListener('click', () => setStatus('returned'));
    $('#reopenBtn')?.addEventListener('click', () => setStatus('open'));
    $('#delBtn')?.addEventListener('click', async () => {
      const ok = await dialog({ title: 'ลบรายการนี้?', text: 'เมื่อลบแล้วจะไม่สามารถกู้คืนได้ และคำขอรับคืนที่เกี่ยวข้องจะถูกลบด้วย', okText: 'ลบรายการ', danger: true });
      if (!ok) return;
      try { await API.del('/api/items/' + i.id); toast('ลบรายการเรียบร้อยแล้ว'); setTimeout(() => (location.href = 'items.html'), 600); }
      catch (e) { toast(e.message, 'err'); }
    });

    $('#claimForm')?.addEventListener('submit', async (e) => {
      e.preventDefault();
      const f = e.target;
      const err = $('#claimErr');
      err.classList.add('hidden');
      const btn = f.querySelector('button');
      btn.disabled = true;
      try {
        await API.post(`/api/items/${i.id}/claims`, { proof: f.proof.value, contact: f.contact.value });
        toast('ส่งคำขอรับคืนเรียบร้อยแล้ว กรุณารอการตรวจสอบ');
        load();
      } catch (ex) {
        err.textContent = ex.message;
        err.classList.remove('hidden');
        btn.disabled = false;
      }
    });
  }

  async function setStatus(status) {
    try {
      await API.patch(`/api/items/${id}/status`, { status });
      toast('อัปเดตสถานะเรียบร้อยแล้ว');
      load();
    } catch (e) { toast(e.message, 'err'); }
  }

  load();
})();
