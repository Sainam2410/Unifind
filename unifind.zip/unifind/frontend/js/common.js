/* ==========================================================================
   frontend/js/common.js — ฟังก์ชันกลางที่ทุกหน้าใช้ร่วมกัน
   หน้าที่:
   - API       : ตัวเรียก backend (แนบ token ให้อัตโนมัติ)
   - Auth      : เก็บ/ตรวจสอบสถานะการเข้าสู่ระบบ
   - boot()    : เตรียมหน้า (เช็คล็อกอิน, สร้างเมนูด้านบนและส่วนท้าย)
   - ตัวช่วย   : esc (กัน XSS), fmtDate (วันที่ไทย), toast, itemCard, resizeImage ฯลฯ
   ========================================================================== */
const $ = (s, r = document) => r.querySelector(s);
const $$ = (s, r = document) => [...r.querySelectorAll(s)];
const qs = (k) => new URLSearchParams(location.search).get(k);

// กันการแทรกโค้ด HTML จากข้อมูลที่ผู้ใช้กรอก
const esc = (s) => String(s ?? '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));

const fmtDate = (d) => {
  if (!d) return '-';
  const dt = new Date(d.length <= 10 ? d + 'T00:00:00' : d);
  return dt.toLocaleDateString('th-TH', { day: 'numeric', month: 'short', year: 'numeric' });
};
const fmtDateTime = (d) => {
  if (!d) return '-';
  return new Date(d).toLocaleString('th-TH', { day: 'numeric', month: 'short', year: 'numeric', hour: '2-digit', minute: '2-digit' }) + ' น.';
};
const todayStr = () => {
  const d = new Date();
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
};

const STATUS = {
  open: { text: 'ยังเปิดอยู่', cls: 'st-open' },
  pending: { text: 'รอตรวจสอบ', cls: 'st-pending' },
  returned: { text: 'รับคืนแล้ว', cls: 'st-returned' },
};
const CLAIM_STATUS = {
  pending: { text: 'รอตรวจสอบ', cls: 'st-pending' },
  approved: { text: 'อนุมัติแล้ว', cls: 'st-returned' },
  rejected: { text: 'ไม่อนุมัติ', cls: 'st-rejected' },
};
const TYPE = {
  lost: { text: 'ของหาย', cls: 'type-lost', icon: '🔍' },
  found: { text: 'พบของ', cls: 'type-found', icon: '🎁' },
};
const badge = (map, key) => {
  const m = map[key] || { text: key, cls: '' };
  return `<span class="badge ${m.cls}">${m.text}</span>`;
};

/* ---------- เรียก API ---------- */
const API = {
  token: () => localStorage.getItem('uf_token'),
  async req(method, url, body) {
    const headers = {};
    if (body !== undefined) headers['Content-Type'] = 'application/json';
    const t = API.token();
    if (t) headers.Authorization = 'Bearer ' + t;
    let res;
    try {
      res = await fetch(url, { method, headers, body: body !== undefined ? JSON.stringify(body) : undefined });
    } catch {
      throw new Error('เชื่อมต่อเซิร์ฟเวอร์ไม่ได้ กรุณาตรวจสอบว่าเปิดเซิร์ฟเวอร์ (npm start) แล้ว');
    }
    const data = await res.json().catch(() => ({}));
    if (!res.ok) {
      if (res.status === 401 && t) Auth.clear(); // token หมดอายุ
      const e = new Error(data.message || 'เกิดข้อผิดพลาด กรุณาลองใหม่');
      e.status = res.status;
      throw e;
    }
    return data;
  },
  get: (u) => API.req('GET', u),
  post: (u, b) => API.req('POST', u, b ?? {}),
  put: (u, b) => API.req('PUT', u, b ?? {}),
  patch: (u, b) => API.req('PATCH', u, b ?? {}),
  del: (u) => API.req('DELETE', u),
};

/* ---------- สถานะการเข้าสู่ระบบ ---------- */
const Auth = {
  user: null,
  async init() {
    if (!API.token()) return null;
    try {
      this.user = (await API.get('/api/auth/me')).user;
    } catch (e) {
      if (e.status === 401) this.clear();
    }
    return this.user;
  },
  save(token, user) { localStorage.setItem('uf_token', token); this.user = user; },
  clear() { localStorage.removeItem('uf_token'); this.user = null; },
  logout() { this.clear(); location.href = 'index.html'; },
};

/* ---------- เมนูด้านบนและส่วนท้าย ---------- */
function renderLayout() {
  const link = document.createElement('link');
  link.rel = 'icon';
  link.href = "data:image/svg+xml,<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 100 100'><text y='.9em' font-size='90'>🔎</text></svg>";
  document.head.appendChild(link);

  const page = location.pathname.split('/').pop() || 'index.html';
  const links = [
    ['index.html', 'หน้าแรก'],
    ['items.html', 'ค้นหาของ'],
    ['report.html?type=lost', 'แจ้งของหาย'],
    ['report.html?type=found', 'แจ้งพบของ'],
  ];
  const active = (href) => href === page || (href.startsWith(page + '?') && !qs('edit') && location.search.includes(href.split('?')[1]));
  const u = Auth.user;

  const right = u
    ? `<div class="user-menu" id="userMenu">
         <button class="user-btn" id="userBtn" aria-haspopup="true"><span class="avatar">${esc(u.name.trim()[0] || '?')}</span><span class="nm">${esc(u.name)}</span></button>
         <div class="menu-pop">
           <div class="who"><b>${esc(u.name)}</b><small>${esc(u.email)}${u.role === 'admin' ? ' · ผู้ดูแลระบบ' : ''}</small></div>
           <a href="my.html">📋 รายการของฉัน</a>
           <a href="my.html?tab=profile">👤 โปรไฟล์</a>
           ${u.role === 'admin' ? '<a href="admin.html">🛡️ ผู้ดูแลระบบ</a>' : ''}
           <button id="logoutBtn">🚪 ออกจากระบบ</button>
         </div>
       </div>`
    : `<a class="btn btn-light btn-sm" href="login.html">เข้าสู่ระบบ</a><a class="btn btn-yellow btn-sm" href="register.html">สมัครสมาชิก</a>`;

  $('#nav').innerHTML = `
    <header class="nav" id="navBar"><div class="container nav-in">
      <a class="brand" href="index.html"><span class="brand-logo">🔎</span>UniFind</a>
      <nav class="nav-links">${links.map(([h, t]) => `<a href="${h}" class="${active(h) ? 'active' : ''}">${t}</a>`).join('')}</nav>
      <div class="nav-right">${right}<button class="burger" id="burger" aria-label="เมนู">☰</button></div>
    </div></header>`;

  $('#footer').innerHTML = `
    <footer class="footer"><div class="container footer-in">
      <div><b>UniFind</b> · ระบบแจ้งของหายภายในมหาวิทยาลัย</div>
      <div>CE306 โปรแกรมประยุกต์บนเว็บ</div>
    </div></footer>`;

  $('#burger').onclick = () => $('#navBar').classList.toggle('open');
  if (u) {
    $('#userBtn').onclick = (e) => { e.stopPropagation(); $('#userMenu').classList.toggle('open'); };
    $('#logoutBtn').onclick = () => Auth.logout();
    document.addEventListener('click', () => $('#userMenu')?.classList.remove('open'));
  }
}

// เตรียมหน้า: auth = 'user' (ต้องล็อกอิน) หรือ 'admin' (ต้องเป็นแอดมิน)
async function boot({ auth } = {}) {
  await Auth.init();
  if (auth && !Auth.user) {
    const next = location.pathname.split('/').pop() + location.search;
    location.replace('login.html?next=' + encodeURIComponent(next));
    return false;
  }
  if (auth === 'admin' && Auth.user.role !== 'admin') {
    location.replace('index.html');
    return false;
  }
  renderLayout();
  return true;
}

/* ---------- ตัวช่วยแสดงผล ---------- */
function toast(msg, type = 'ok') {
  let box = $('#toasts');
  if (!box) { box = document.createElement('div'); box.id = 'toasts'; document.body.appendChild(box); }
  const t = document.createElement('div');
  t.className = 'toast ' + (type === 'err' ? 'err' : '');
  t.textContent = msg;
  box.appendChild(t);
  setTimeout(() => { t.classList.add('hide'); setTimeout(() => t.remove(), 300); }, 3400);
}

const loadingHtml = (t = 'กำลังโหลดข้อมูล...') => `<div class="loading"><div class="spinner"></div>${t}</div>`;
const emptyBox = (icon, title, text = '') => `<div class="empty"><div class="ic">${icon}</div><h3>${esc(title)}</h3><p>${esc(text)}</p></div>`;

function itemCard(i) {
  const thumb = i.imageUrl
    ? `<img src="${i.imageUrl}" alt="${esc(i.title)}" loading="lazy">`
    : `<div class="thumb-ph">${esc(i.categoryIcon)}</div>`;
  return `<a class="item-card" href="item-detail.html?id=${i.id}">
    <div class="item-thumb">${thumb}<span class="badge corner ${TYPE[i.type].cls}">${TYPE[i.type].text}</span></div>
    <div class="item-body">
      <h3>${esc(i.title)}</h3>
      <p class="meta"><span>📍</span><span>${esc(i.location)}</span></p>
      <p class="meta"><span>📅</span><span>${fmtDate(i.date)}</span></p>
      <div class="item-foot"><span class="chip">${esc(i.categoryIcon)} ${esc(i.categoryName)}</span>${badge(STATUS, i.status)}</div>
    </div></a>`;
}

function renderPager(el, page, pages, onGo) {
  if (pages <= 1) { el.innerHTML = ''; el.onclick = null; return; }
  let h = `<button ${page <= 1 ? 'disabled' : ''} data-p="${page - 1}">‹ ก่อนหน้า</button>`;
  for (let p = 1; p <= pages; p++) {
    if (p === 1 || p === pages || Math.abs(p - page) <= 1) h += `<button class="${p === page ? 'on' : ''}" data-p="${p}">${p}</button>`;
    else if (Math.abs(p - page) === 2) h += '<span>…</span>';
  }
  h += `<button ${page >= pages ? 'disabled' : ''} data-p="${page + 1}">ถัดไป ›</button>`;
  el.innerHTML = h;
  el.onclick = (e) => {
    const b = e.target.closest('button[data-p]');
    if (b && !b.disabled) onGo(Number(b.dataset.p));
  };
}

// หน้าต่างยืนยัน/กรอกหมายเหตุ (ใช้แทน confirm/prompt ให้ดูสวย)
function dialog({ title, text = '', input = null, okText = 'ตกลง', danger = false }) {
  return new Promise((resolve) => {
    const bg = document.createElement('div');
    bg.className = 'modal-bg';
    bg.innerHTML = `<div class="modal" role="dialog">
      <h3>${esc(title)}</h3><p class="muted">${esc(text)}</p>
      ${input ? `<div class="field" style="margin:14px 0 0"><label>${esc(input)}</label><textarea id="dlgInput" style="min-height:80px"></textarea></div>` : ''}
      <div class="btn-row"><button class="btn btn-ghost btn-sm" id="dlgNo">ยกเลิก</button><button class="btn btn-sm ${danger ? 'btn-danger' : 'btn-primary'}" id="dlgOk">${esc(okText)}</button></div>
    </div>`;
    document.body.appendChild(bg);
    const close = (v) => { bg.remove(); resolve(v); };
    $('#dlgNo', bg).onclick = () => close(null);
    $('#dlgOk', bg).onclick = () => close(input ? $('#dlgInput', bg).value.trim() : true);
    bg.addEventListener('click', (e) => { if (e.target === bg) close(null); });
    $('#dlgInput', bg)?.focus();
  });
}

// ย่อรูปภาพก่อนอัปโหลด เพื่อไม่ให้ไฟล์ใหญ่เกินไป
function resizeImage(file, max = 900, quality = 0.82) {
  return new Promise((resolve, reject) => {
    if (!file.type.startsWith('image/')) return reject(new Error('กรุณาเลือกไฟล์รูปภาพเท่านั้น'));
    const reader = new FileReader();
    reader.onerror = () => reject(new Error('อ่านไฟล์ไม่สำเร็จ'));
    reader.onload = () => {
      const img = new Image();
      img.onerror = () => reject(new Error('ไฟล์รูปภาพไม่ถูกต้อง'));
      img.onload = () => {
        const r = Math.min(1, max / Math.max(img.width, img.height));
        const c = document.createElement('canvas');
        c.width = Math.round(img.width * r);
        c.height = Math.round(img.height * r);
        const ctx = c.getContext('2d');
        ctx.fillStyle = '#fff';
        ctx.fillRect(0, 0, c.width, c.height);
        ctx.drawImage(img, 0, 0, c.width, c.height);
        resolve(c.toDataURL('image/jpeg', quality));
      };
      img.src = reader.result;
    };
    reader.readAsDataURL(file);
  });
}

// ใช้ป้องกันไม่ให้ next= พาไปเว็บอื่น
const safeNext = (n) => (n && /^[\w\-./?=&%]+$/.test(n) && !n.startsWith('//') ? n : 'index.html');
