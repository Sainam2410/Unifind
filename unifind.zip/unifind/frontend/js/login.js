/* ==========================================================================
   frontend/js/login.js — สคริปต์หน้าเข้าสู่ระบบ
   หน้าที่: ส่งอีเมล/รหัสผ่านไป /api/auth/login เก็บ token แล้วพากลับหน้าที่มาจาก (?next=)
   ========================================================================== */
(async () => {
  if (!(await boot())) return;
  if (Auth.user) { location.replace(safeNext(qs('next'))); return; }

  $('#form').addEventListener('submit', async (e) => {
    e.preventDefault();
    const f = e.target;
    const err = $('#err');
    err.classList.add('hidden');
    if (!f.email.value.trim() || !f.password.value) {
      err.textContent = 'กรุณากรอกอีเมลและรหัสผ่าน';
      err.classList.remove('hidden');
      return;
    }
    $('#btn').disabled = true;
    try {
      const r = await API.post('/api/auth/login', { email: f.email.value, password: f.password.value });
      Auth.save(r.token, r.user);
      location.href = safeNext(qs('next'));
    } catch (ex) {
      err.textContent = ex.message;
      err.classList.remove('hidden');
      $('#btn').disabled = false;
    }
  });
})();
