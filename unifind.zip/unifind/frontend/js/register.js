/* ==========================================================================
   frontend/js/register.js — สคริปต์หน้าสมัครสมาชิก
   หน้าที่: ตรวจข้อมูลเบื้องต้น (รหัสผ่านตรงกัน) แล้วส่งไป /api/auth/register จากนั้นเข้าสู่ระบบให้ทันที
   ========================================================================== */
(async () => {
  if (!(await boot())) return;
  if (Auth.user) { location.replace('index.html'); return; }

  $('#form').addEventListener('submit', async (e) => {
    e.preventDefault();
    const f = e.target;
    const err = $('#err');
    err.classList.add('hidden');
    const fail = (m) => { err.textContent = m; err.classList.remove('hidden'); };

    if (f.name.value.trim().length < 2) return fail('กรุณากรอกชื่อ-นามสกุล');
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(f.email.value.trim())) return fail('รูปแบบอีเมลไม่ถูกต้อง');
    if (f.password.value.length < 6) return fail('รหัสผ่านต้องมีอย่างน้อย 6 ตัวอักษร');
    if (f.password.value !== f.confirm.value) return fail('รหัสผ่านและการยืนยันรหัสผ่านไม่ตรงกัน');

    $('#btn').disabled = true;
    try {
      const r = await API.post('/api/auth/register', {
        name: f.name.value, email: f.email.value, studentId: f.studentId.value, phone: f.phone.value, password: f.password.value,
      });
      Auth.save(r.token, r.user);
      location.href = 'index.html';
    } catch (ex) {
      fail(ex.message);
      $('#btn').disabled = false;
    }
  });
})();
