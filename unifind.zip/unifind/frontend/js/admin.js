/* ==========================================================================
   frontend/js/admin.js — สคริปต์หน้าผู้ดูแลระบบ
   หน้าที่:
   - ภาพรวม   : ตัวเลขสรุป กราฟรายการ 14 วัน และจำนวนตามหมวดหมู่ (ข้อมูลจริงจากระบบ)
   - รายการ   : ค้นหา/กรอง เปลี่ยนสถานะ ลบรายการ
   - คำขอรับคืน: อนุมัติ/ไม่อนุมัติ พร้อมหมายเหตุ
   - หมวดหมู่  : เพิ่ม แก้ไข ลบ
   - ผู้ใช้    : ดูรายชื่อ และเปลี่ยนสิทธิ์ (user/admin)
   ========================================================================== */
(async () => {
  if (!(await boot({ auth: 'admin' }))) return;
  const panel = $('#panel');
  let tab = ['dash', 'items', 'claims', 'cats', 'users'].includes(qs('tab')) ? qs('tab') : 'dash';
  const itemsState = { search: '', type: '', status: '', page: 1 };
  let claimFilter = 'pending';

  const views = { dash: showDash, items: showItems, claims: showClaims, cats: showCats, users: showUsers };
  function setTab(t) {
    tab = t;
    $$('#tabs button').forEach((b) => b.classList.toggle('on', b.dataset.tab === t));
    history.replaceState(null, '', t === 'dash' ? location.pathname : '?tab=' + t);
    views[t]();
  }
  $('#tabs').addEventListener('click', (e) => { const b = e.target.closest('button'); if (b) setTab(b.dataset.tab); });
  const fail = (msg) => { panel.innerHTML = emptyBox('⚠️', 'โหลดข้อมูลไม่สำเร็จ', msg); };

  // ---------- ภาพรวม ----------
  async function showDash() {
    panel.innerHTML = loadingHtml();
    try {
      const d = await API.get('/api/admin/dashboard');
      const t = d.totals;
      const max = Math.max(1, ...d.last14.map((x) => x.count));
      const maxCat = Math.max(1, ...d.byCategory.map((x) => x.count));
      panel.innerHTML = `
        <div class="kpis">
          <div class="kpi"><div class="ic">🔍</div><div><b>${t.lost}</b><span>รายการของหาย</span></div></div>
          <div class="kpi"><div class="ic">🎁</div><div><b>${t.found}</b><span>รายการของที่พบ</span></div></div>
          <div class="kpi"><div class="ic">📂</div><div><b>${t.open + t.pendingItems}</b><span>ยังเปิดอยู่</span></div></div>
          <div class="kpi"><div class="ic">✅</div><div><b>${t.returned}</b><span>ส่งคืนแล้ว</span></div></div>
          <div class="kpi hot"><div class="ic">⏳</div><div><b>${t.pendingClaims}</b><span>คำขอที่รอตรวจสอบ</span></div></div>
          <div class="kpi"><div class="ic">👥</div><div><b>${t.users}</b><span>ผู้ใช้ทั้งหมด</span></div></div>
          <div class="kpi"><div class="ic">📦</div><div><b>${t.items}</b><span>รายการทั้งหมด</span></div></div>
          <div class="kpi"><div class="ic">📈</div><div><b>${t.items ? Math.round((t.returned / t.items) * 100) : 0}%</b><span>อัตราการส่งคืน</span></div></div>
        </div>
        <div class="dash-grid">
          <div class="card"><h3>รายการที่แจ้งใหม่ 14 วันล่าสุด</h3>
            <div class="bars">${d.last14.map((x) => `<div class="bar-col"><span class="v">${x.count || ''}</span><div class="bar ${x.count ? '' : 'zero'}" style="height:${Math.max(3, (x.count / max) * 100)}%"></div><small>${x.date.slice(8)}/${x.date.slice(5, 7)}</small></div>`).join('')}</div>
          </div>
          <div class="card"><h3>จำนวนรายการตามหมวดหมู่</h3>
            ${d.byCategory.map((c) => `<div class="cat-row"><div class="top"><span>${esc(c.icon)} ${esc(c.name)}</span><b>${c.count}</b></div><div class="track"><i style="width:${(c.count / maxCat) * 100}%"></i></div></div>`).join('')}
          </div>
        </div>
        <div class="section-head" style="margin-top:28px"><h2 style="font-size:1.25rem">รายการล่าสุด</h2></div>
        <div class="grid">${d.recent.map(itemCard).join('') || emptyBox('📭', 'ยังไม่มีรายการ')}</div>`;
      updateClaimBadge(t.pendingClaims);
    } catch (e) { fail(e.message); }
  }

  function updateClaimBadge(n) {
    $('#claimCount').textContent = n;
    $('#claimCount').classList.toggle('hidden', !n);
  }

  // ---------- รายการ ----------
  function showItems() {
    panel.innerHTML = `
      <div class="toolbar">
        <input class="grow" id="aSearch" type="search" placeholder="ค้นหาชื่อ รายละเอียด หรือสถานที่" value="${esc(itemsState.search)}">
        <select id="aType"><option value="">ทุกประเภท</option><option value="lost">ของหาย</option><option value="found">พบของ</option></select>
        <select id="aStatus"><option value="">ทุกสถานะ</option><option value="open">ยังเปิดอยู่</option><option value="pending">รอตรวจสอบ</option><option value="returned">รับคืนแล้ว</option></select>
      </div>
      <div id="aTable">${loadingHtml()}</div><div class="pager" id="aPager"></div>`;
    $('#aType').value = itemsState.type;
    $('#aStatus').value = itemsState.status;
    let timer;
    $('#aSearch').addEventListener('input', (e) => { itemsState.search = e.target.value.trim(); itemsState.page = 1; clearTimeout(timer); timer = setTimeout(loadItems, 300); });
    $('#aType').addEventListener('change', (e) => { itemsState.type = e.target.value; itemsState.page = 1; loadItems(); });
    $('#aStatus').addEventListener('change', (e) => { itemsState.status = e.target.value; itemsState.page = 1; loadItems(); });
    loadItems();
  }

  async function loadItems() {
    const p = new URLSearchParams({ pageSize: 12, page: itemsState.page });
    ['search', 'type', 'status'].forEach((k) => { if (itemsState[k]) p.set(k, itemsState[k]); });
    try {
      const r = await API.get('/api/items?' + p);
      itemsState.page = r.page;
      $('#aTable').innerHTML = r.items.length ? `<div class="table-wrap"><table>
        <thead><tr><th>รายการ</th><th>ประเภท</th><th>หมวดหมู่</th><th>สถานที่</th><th>วันที่</th><th>ผู้แจ้ง</th><th>สถานะ</th><th></th></tr></thead>
        <tbody>${r.items.map((i) => `<tr>
          <td><a href="item-detail.html?id=${i.id}"><b>${esc(i.title)}</b></a></td>
          <td><span class="badge ${TYPE[i.type].cls}">${TYPE[i.type].text}</span></td>
          <td>${esc(i.categoryIcon)} ${esc(i.categoryName)}</td>
          <td>${esc(i.location)}</td><td>${fmtDate(i.date)}</td><td>${esc(i.reporterName)}</td>
          <td><select data-act="status" data-id="${i.id}">${Object.entries(STATUS).map(([k, v]) => `<option value="${k}" ${i.status === k ? 'selected' : ''}>${v.text}</option>`).join('')}</select></td>
          <td style="white-space:nowrap"><a class="btn btn-ghost btn-sm" href="report.html?edit=${i.id}">แก้ไข</a> <button class="btn btn-danger btn-sm" data-act="del" data-id="${i.id}">ลบ</button></td>
        </tr>`).join('')}</tbody></table></div>` : emptyBox('🕵️', 'ไม่พบรายการ', 'ลองเปลี่ยนเงื่อนไขการค้นหา');
      renderPager($('#aPager'), r.page, r.pages, (n) => { itemsState.page = n; loadItems(); });
    } catch (e) { $('#aTable').innerHTML = emptyBox('⚠️', 'โหลดข้อมูลไม่สำเร็จ', e.message); }
  }

  // ---------- คำขอรับคืน ----------
  async function showClaims() {
    panel.innerHTML = `<div class="toolbar"><select id="cFilter">
      <option value="pending">รอตรวจสอบ</option><option value="approved">อนุมัติแล้ว</option><option value="rejected">ไม่อนุมัติ</option><option value="">ทั้งหมด</option></select></div>
      <div id="cList">${loadingHtml()}</div>`;
    $('#cFilter').value = claimFilter;
    $('#cFilter').addEventListener('change', (e) => { claimFilter = e.target.value; showClaims(); });
    try {
      const { claims } = await API.get('/api/claims' + (claimFilter ? '?status=' + claimFilter : ''));
      $('#cList').innerHTML = claims.length ? `<div class="row-list">${claims.map((c) => `
        <div class="claim-card">
          <div class="claim-head">
            <div><a href="item-detail.html?id=${c.itemId}"><b>${esc(c.itemTitle)}</b></a>
              <div class="muted" style="font-size:.86rem">ผู้ขอ: ${esc(c.claimerName)}${c.claimerStudentId ? ' (' + esc(c.claimerStudentId) + ')' : ''} · ${esc(c.claimerEmail)} · ส่งเมื่อ ${fmtDateTime(c.createdAt)}</div></div>
            ${badge(CLAIM_STATUS, c.status)}
          </div>
          <div class="proof">${esc(c.proof)}</div>
          <div class="muted" style="font-size:.9rem">☎️ ติดต่อกลับ: ${esc(c.contact)}</div>
          ${c.note ? `<div class="note" style="margin-top:6px">หมายเหตุ: ${esc(c.note)}</div>` : ''}
          ${c.status === 'pending' ? `<div class="btn-row" style="margin-top:12px"><button class="btn btn-ok btn-sm" data-act="approve" data-id="${c.id}">✅ อนุมัติ</button><button class="btn btn-danger btn-sm" data-act="reject" data-id="${c.id}">ไม่อนุมัติ</button></div>` : ''}
        </div>`).join('')}</div>` : emptyBox('📭', 'ไม่มีคำขอในหมวดนี้');
      if (claimFilter === 'pending') updateClaimBadge(claims.length);
    } catch (e) { $('#cList').innerHTML = emptyBox('⚠️', 'โหลดข้อมูลไม่สำเร็จ', e.message); }
  }

  // ---------- หมวดหมู่ ----------
  async function showCats() {
    panel.innerHTML = loadingHtml();
    try {
      const [{ categories }, dash] = await Promise.all([API.get('/api/categories'), API.get('/api/admin/dashboard')]);
      const count = Object.fromEntries(dash.byCategory.map((c) => [c.id, c.count]));
      panel.innerHTML = `
        <div class="card" style="margin-bottom:20px"><h3>เพิ่มหมวดหมู่ใหม่</h3>
          <form id="catForm" class="toolbar" style="margin:0" novalidate>
            <input type="text" name="icon" maxlength="4" placeholder="🏷️" style="min-width:0;width:80px;text-align:center">
            <input class="grow" type="text" name="name" maxlength="40" placeholder="ชื่อหมวดหมู่ เช่น อุปกรณ์กีฬา" required>
            <button class="btn btn-primary" type="submit">เพิ่มหมวดหมู่</button>
          </form></div>
        <div class="table-wrap"><table><thead><tr><th>ไอคอน</th><th>ชื่อหมวดหมู่</th><th>จำนวนรายการ</th><th></th></tr></thead>
        <tbody>${categories.map((c) => `<tr><td style="font-size:1.4rem">${esc(c.icon)}</td><td>${esc(c.name)}</td><td>${count[c.id] || 0}</td>
          <td style="white-space:nowrap"><button class="btn btn-ghost btn-sm" data-act="editcat" data-id="${c.id}" data-name="${esc(c.name)}" data-icon="${esc(c.icon)}">แก้ไข</button>
          <button class="btn btn-danger btn-sm" data-act="delcat" data-id="${c.id}">ลบ</button></td></tr>`).join('')}</tbody></table></div>`;
      $('#catForm').addEventListener('submit', async (e) => {
        e.preventDefault();
        try {
          await API.post('/api/admin/categories', { name: e.target.name.value, icon: e.target.icon.value });
          toast('เพิ่มหมวดหมู่แล้ว'); showCats();
        } catch (ex) { toast(ex.message, 'err'); }
      });
    } catch (e) { fail(e.message); }
  }

  // ---------- ผู้ใช้ ----------
  async function showUsers() {
    panel.innerHTML = loadingHtml();
    try {
      const { users } = await API.get('/api/admin/users');
      panel.innerHTML = `<div class="table-wrap"><table>
        <thead><tr><th>ชื่อ</th><th>อีเมล</th><th>รหัส</th><th>โทร</th><th>รายการที่แจ้ง</th><th>สมัครเมื่อ</th><th>สิทธิ์</th></tr></thead>
        <tbody>${users.map((u) => `<tr><td><b>${esc(u.name)}</b></td><td>${esc(u.email)}</td><td>${esc(u.studentId || '-')}</td><td>${esc(u.phone || '-')}</td><td>${u.itemCount}</td><td>${fmtDate(u.createdAt)}</td>
          <td>${u.id === Auth.user.id ? '<span class="badge st-open">ผู้ดูแล (คุณ)</span>' : `<select data-act="role" data-id="${u.id}"><option value="user" ${u.role === 'user' ? 'selected' : ''}>ผู้ใช้ทั่วไป</option><option value="admin" ${u.role === 'admin' ? 'selected' : ''}>ผู้ดูแลระบบ</option></select>`}</td></tr>`).join('')}</tbody></table></div>`;
    } catch (e) { fail(e.message); }
  }

  // ---------- จัดการเหตุการณ์คลิก/เปลี่ยนค่าในตาราง ----------
  panel.addEventListener('change', async (e) => {
    const el = e.target.closest('select[data-act]');
    if (!el) return;
    try {
      if (el.dataset.act === 'status') { await API.patch(`/api/items/${el.dataset.id}/status`, { status: el.value }); toast('อัปเดตสถานะแล้ว'); }
      if (el.dataset.act === 'role') { await API.patch(`/api/admin/users/${el.dataset.id}/role`, { role: el.value }); toast('เปลี่ยนสิทธิ์ผู้ใช้แล้ว'); }
    } catch (ex) { toast(ex.message, 'err'); setTab(tab); }
  });

  panel.addEventListener('click', async (e) => {
    const b = e.target.closest('button[data-act]');
    if (!b) return;
    const id = b.dataset.id;
    try {
      switch (b.dataset.act) {
        case 'del':
          if (!(await dialog({ title: 'ลบรายการนี้?', text: 'คำขอรับคืนที่เกี่ยวข้องจะถูกลบด้วย และกู้คืนไม่ได้', okText: 'ลบรายการ', danger: true }))) return;
          await API.del('/api/items/' + id); toast('ลบรายการแล้ว'); loadItems(); break;
        case 'approve':
        case 'reject': {
          const ok = b.dataset.act === 'approve';
          const note = await dialog({ title: ok ? 'อนุมัติคำขอรับคืน' : 'ไม่อนุมัติคำขอ', text: ok ? 'รายการจะถูกเปลี่ยนเป็น "รับคืนแล้ว"' : 'ระบุเหตุผลเพื่อให้ผู้ขอทราบ', input: 'หมายเหตุถึงผู้ขอ (ไม่บังคับ)', okText: ok ? 'อนุมัติ' : 'ไม่อนุมัติ', danger: !ok });
          if (note === null) return;
          await API.patch('/api/claims/' + id, { status: ok ? 'approved' : 'rejected', note });
          toast('บันทึกผลการตรวจสอบแล้ว'); showClaims(); break;
        }
        case 'editcat': {
          const bg = document.createElement('div');
          bg.className = 'modal-bg';
          bg.innerHTML = `<div class="modal"><h3>แก้ไขหมวดหมู่</h3>
            <div class="row2" style="grid-template-columns:90px 1fr;margin-top:12px"><div class="field"><label>ไอคอน</label><input id="ecIcon" type="text" maxlength="4" value="${esc(b.dataset.icon)}"></div>
            <div class="field"><label>ชื่อ</label><input id="ecName" type="text" maxlength="40" value="${esc(b.dataset.name)}"></div></div>
            <div class="btn-row"><button class="btn btn-ghost btn-sm" id="ecNo">ยกเลิก</button><button class="btn btn-primary btn-sm" id="ecOk">บันทึก</button></div></div>`;
          document.body.appendChild(bg);
          $('#ecNo', bg).onclick = () => bg.remove();
          $('#ecOk', bg).onclick = async () => {
            try {
              await API.put('/api/admin/categories/' + id, { name: $('#ecName', bg).value, icon: $('#ecIcon', bg).value });
              bg.remove(); toast('แก้ไขหมวดหมู่แล้ว'); showCats();
            } catch (ex) { toast(ex.message, 'err'); }
          };
          break;
        }
        case 'delcat':
          if (!(await dialog({ title: 'ลบหมวดหมู่นี้?', text: 'ลบได้เฉพาะหมวดหมู่ที่ยังไม่มีรายการใช้งาน', okText: 'ลบ', danger: true }))) return;
          await API.del('/api/admin/categories/' + id); toast('ลบหมวดหมู่แล้ว'); showCats(); break;
      }
    } catch (ex) { toast(ex.message, 'err'); }
  });

  // แสดงตัวเลขคำขอที่รอตรวจสอบบนแท็บตั้งแต่เปิดหน้า
  API.get('/api/claims?status=pending').then((r) => updateClaimBadge(r.claims.length)).catch(() => {});
  setTab(tab);
})();
