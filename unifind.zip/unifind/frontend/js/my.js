/* ==========================================================================
   frontend/js/my.js — สคริปต์หน้า "พื้นที่ของฉัน"
   หน้าที่:
   - แท็บรายการของฉัน : ดู/แก้ไข/ทำเครื่องหมายส่งคืน/ลบ
   - แท็บคำขอรับคืนของฉัน : ดูสถานะ และยกเลิกคำขอที่ยังรอตรวจสอบ
   - แท็บคำขอที่ส่งถึงฉัน : ผู้ที่แจ้งพบของอนุมัติ/ไม่อนุมัติคำขอ
   - แท็บโปรไฟล์ : แก้ไขชื่อ เบอร์โทร และเปลี่ยนรหัสผ่าน
   ========================================================================== */
(async () => {
  if (!(await boot({ auth: 'user' }))) return;
  const panel = $('#panel');
  let tab = ['items', 'claims', 'received', 'profile'].includes(qs('tab')) ? qs('tab') : 'items';

  function setTab(t) {
    tab = t;
    $$('#tabs button').forEach((b) => b.classList.toggle('on', b.dataset.tab === t));
    history.replaceState(null, '', t === 'items' ? location.pathname : '?tab=' + t);
    ({ items: showItems, claims: showClaims, received: showReceived, profile: showProfile })[t]();
  }
  $('#tabs').addEventListener('click', (e) => { const b = e.target.closest('button'); if (b) setTab(b.dataset.tab); });

  // ---------- รายการของฉัน ----------
  async function showItems() {
    panel.innerHTML = loadingHtml();
    try {
      const { items } = await API.get('/api/items?mine=1&pageSize=100');
      if (!items.length) {
        panel.innerHTML = emptyBox('📭', 'คุณยังไม่ได้แจ้งรายการใด ๆ', 'เริ่มแจ้งของหายหรือแจ้งพบของได้เลย') +
          `<div class="btn-row" style="justify-content:center;margin-top:16px"><a class="btn btn-primary" href="report.html?type=lost">📝 แจ้งของหาย</a><a class="btn btn-yellow" href="report.html?type=found">🎁 แจ้งพบของ</a></div>`;
        return;
      }
      panel.innerHTML = `<div class="row-list">${items.map((i) => `
        <div class="row-card">
          <div class="row-thumb">${i.imageUrl ? `<img src="${i.imageUrl}" alt="">` : esc(i.categoryIcon)}</div>
          <div class="row-main">
            <div class="badges" style="margin-bottom:4px"><span class="badge ${TYPE[i.type].cls}">${TYPE[i.type].text}</span>${badge(STATUS, i.status)}</div>
            <h3><a href="item-detail.html?id=${i.id}" style="color:inherit">${esc(i.title)}</a></h3>
            <p class="meta"><span>📍 ${esc(i.location)}</span><span>📅 ${fmtDate(i.date)}</span></p>
          </div>
          <div class="row-actions">
            <a class="btn btn-ghost btn-sm" href="item-detail.html?id=${i.id}">ดู</a>
            <a class="btn btn-ghost btn-sm" href="report.html?edit=${i.id}">แก้ไข</a>
            ${i.status === 'returned' ? `<button class="btn btn-ghost btn-sm" data-act="open" data-id="${i.id}">เปิดอีกครั้ง</button>` : `<button class="btn btn-ok btn-sm" data-act="return" data-id="${i.id}">ส่งคืนแล้ว</button>`}
            <button class="btn btn-danger btn-sm" data-act="del" data-id="${i.id}">ลบ</button>
          </div>
        </div>`).join('')}</div>`;
    } catch (e) { panel.innerHTML = emptyBox('⚠️', 'โหลดข้อมูลไม่สำเร็จ', e.message); }
  }

  // ---------- การ์ดคำขอรับคืน ----------
  function claimCard(c, mode) {
    return `<div class="claim-card">
      <div class="claim-head">
        <div><a href="item-detail.html?id=${c.itemId}"><b>${esc(c.itemTitle)}</b></a>
          <div class="muted" style="font-size:.86rem">${mode === 'received' ? `ผู้ขอ: ${esc(c.claimerName)}${c.claimerStudentId ? ' (' + esc(c.claimerStudentId) + ')' : ''} · ` : ''}ส่งเมื่อ ${fmtDateTime(c.createdAt)}</div></div>
        ${badge(CLAIM_STATUS, c.status)}
      </div>
      <div class="proof">${esc(c.proof)}</div>
      <div class="muted" style="font-size:.9rem">☎️ ติดต่อกลับ: ${esc(c.contact)}</div>
      ${c.note ? `<div class="note" style="margin-top:6px">หมายเหตุ: ${esc(c.note)}</div>` : ''}
      ${c.status === 'pending' ? `<div class="btn-row" style="margin-top:12px">${mode === 'received'
        ? `<button class="btn btn-ok btn-sm" data-act="approve" data-id="${c.id}">✅ อนุมัติ</button><button class="btn btn-danger btn-sm" data-act="reject" data-id="${c.id}">ไม่อนุมัติ</button>`
        : `<button class="btn btn-danger btn-sm" data-act="cancel" data-id="${c.id}">ยกเลิกคำขอ</button>`}</div>` : ''}
    </div>`;
  }

  async function showClaims() {
    panel.innerHTML = loadingHtml();
    try {
      const { claims } = await API.get('/api/claims/mine');
      panel.innerHTML = claims.length
        ? `<div class="row-list">${claims.map((c) => claimCard(c, 'mine')).join('')}</div>`
        : emptyBox('📨', 'ยังไม่มีคำขอรับคืน', 'เมื่อพบสิ่งของของคุณ ให้กดส่งคำขอรับคืนที่หน้ารายละเอียด');
    } catch (e) { panel.innerHTML = emptyBox('⚠️', 'โหลดข้อมูลไม่สำเร็จ', e.message); }
  }

  async function showReceived() {
    panel.innerHTML = loadingHtml();
    try {
      const { claims } = await API.get('/api/claims/received');
      panel.innerHTML = claims.length
        ? `<p class="muted" style="margin-bottom:14px">ตรวจสอบรายละเอียดที่ผู้ขออธิบาย แล้วเลือกอนุมัติเมื่อมั่นใจว่าเป็นเจ้าของจริง</p><div class="row-list">${claims.map((c) => claimCard(c, 'received')).join('')}</div>`
        : emptyBox('📬', 'ยังไม่มีคำขอที่ส่งถึงคุณ', 'คำขอรับคืนสำหรับรายการที่คุณแจ้งพบจะแสดงที่นี่');
    } catch (e) { panel.innerHTML = emptyBox('⚠️', 'โหลดข้อมูลไม่สำเร็จ', e.message); }
  }

  async function refreshReceivedCount() {
    try {
      const { claims } = await API.get('/api/claims/received');
      const n = claims.filter((c) => c.status === 'pending').length;
      $('#recvCount').textContent = n;
      $('#recvCount').classList.toggle('hidden', !n);
    } catch { /* ข้ามได้ */ }
  }

  // ---------- โปรไฟล์ ----------
  function showProfile() {
    const u = Auth.user;
    panel.innerHTML = `<div class="card" style="max-width:600px">
      <h3>ข้อมูลส่วนตัว</h3>
      <div class="form-error hidden" id="pErr"></div>
      <form id="pForm" novalidate>
        <div class="field"><label>อีเมล</label><input type="email" value="${esc(u.email)}" disabled></div>
        <div class="field"><label>ชื่อ-นามสกุล</label><input type="text" name="name" value="${esc(u.name)}" maxlength="60" required></div>
        <div class="row2">
          <div class="field"><label>รหัสนักศึกษา / บุคลากร</label><input type="text" name="studentId" value="${esc(u.studentId || '')}" maxlength="20"></div>
          <div class="field"><label>เบอร์โทรศัพท์</label><input type="tel" name="phone" value="${esc(u.phone || '')}" maxlength="20"></div>
        </div>
        <h3 style="margin:24px 0 4px">เปลี่ยนรหัสผ่าน</h3>
        <p class="hint" style="margin-bottom:12px">เว้นว่างไว้หากไม่ต้องการเปลี่ยน</p>
        <div class="row2">
          <div class="field"><label>รหัสผ่านปัจจุบัน</label><input type="password" name="currentPassword" autocomplete="current-password"></div>
          <div class="field"><label>รหัสผ่านใหม่</label><input type="password" name="newPassword" minlength="6" autocomplete="new-password"></div>
        </div>
        <button class="btn btn-primary" type="submit">บันทึกการเปลี่ยนแปลง</button>
      </form></div>`;
    $('#pForm').addEventListener('submit', async (e) => {
      e.preventDefault();
      const f = e.target;
      const err = $('#pErr');
      err.classList.add('hidden');
      try {
        const body = { name: f.name.value, studentId: f.studentId.value, phone: f.phone.value };
        if (f.newPassword.value) { body.newPassword = f.newPassword.value; body.currentPassword = f.currentPassword.value; }
        const r = await API.put('/api/auth/me', body);
        Auth.user = r.user;
        toast('บันทึกข้อมูลเรียบร้อยแล้ว');
        f.currentPassword.value = f.newPassword.value = '';
        renderLayout();
      } catch (ex) { err.textContent = ex.message; err.classList.remove('hidden'); }
    });
  }

  // ---------- ปุ่มต่าง ๆ ในแท็บ ----------
  panel.addEventListener('click', async (e) => {
    const b = e.target.closest('button[data-act]');
    if (!b) return;
    const id = b.dataset.id;
    try {
      switch (b.dataset.act) {
        case 'return': await API.patch(`/api/items/${id}/status`, { status: 'returned' }); toast('ทำเครื่องหมายส่งคืนแล้ว'); break;
        case 'open': await API.patch(`/api/items/${id}/status`, { status: 'open' }); toast('เปิดรายการอีกครั้งแล้ว'); break;
        case 'del':
          if (!(await dialog({ title: 'ลบรายการนี้?', text: 'ลบแล้วไม่สามารถกู้คืนได้', okText: 'ลบรายการ', danger: true }))) return;
          await API.del('/api/items/' + id); toast('ลบรายการแล้ว'); break;
        case 'cancel':
          if (!(await dialog({ title: 'ยกเลิกคำขอรับคืน?', okText: 'ยกเลิกคำขอ', danger: true }))) return;
          await API.del('/api/claims/' + id); toast('ยกเลิกคำขอแล้ว'); break;
        case 'approve':
        case 'reject': {
          const ok = b.dataset.act === 'approve';
          const note = await dialog({ title: ok ? 'อนุมัติคำขอรับคืน' : 'ไม่อนุมัติคำขอ', text: ok ? 'รายการจะถูกเปลี่ยนเป็น "รับคืนแล้ว"' : 'ระบุเหตุผลเพื่อให้ผู้ขอทราบ', input: 'หมายเหตุถึงผู้ขอ (ไม่บังคับ)', okText: ok ? 'อนุมัติ' : 'ไม่อนุมัติ', danger: !ok });
          if (note === null) return;
          await API.patch('/api/claims/' + id, { status: ok ? 'approved' : 'rejected', note });
          toast('บันทึกผลการตรวจสอบแล้ว');
          break;
        }
      }
      setTab(tab);
      refreshReceivedCount();
    } catch (ex) { toast(ex.message, 'err'); }
  });

  refreshReceivedCount();
  setTab(tab);
})();
