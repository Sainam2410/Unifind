/* ==========================================================================
   frontend/js/home.js — สคริปต์หน้าแรก
   หน้าที่: ส่งคำค้นไปหน้าค้นหา, โหลดตัวเลขสรุป และรายการล่าสุด 6 รายการ
   ========================================================================== */
(async () => {
  if (!(await boot())) return;

  $('#heroForm').addEventListener('submit', (e) => {
    e.preventDefault();
    const v = $('#heroSearch').value.trim();
    location.href = 'items.html' + (v ? '?search=' + encodeURIComponent(v) : '');
  });

  try {
    const s = await API.get('/api/stats');
    $('#statLost').textContent = s.lost;
    $('#statFound').textContent = s.found;
    $('#statOpen').textContent = s.open;
    $('#statReturned').textContent = s.returned;
  } catch { /* ไม่แสดงอะไรถ้าโหลดตัวเลขไม่ได้ */ }

  const box = $('#recent');
  box.innerHTML = loadingHtml();
  try {
    const r = await API.get('/api/items?pageSize=6');
    box.innerHTML = r.items.length ? r.items.map(itemCard).join('') : emptyBox('📭', 'ยังไม่มีรายการ', 'เป็นคนแรกที่แจ้งรายการได้เลย');
    if (!r.items.length) box.style.display = 'block';
  } catch (e) {
    box.style.display = 'block';
    box.innerHTML = emptyBox('⚠️', 'โหลดข้อมูลไม่สำเร็จ', e.message);
  }
})();
