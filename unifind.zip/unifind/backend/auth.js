/* ==========================================================================
   backend/auth.js — ระบบยืนยันตัวตนและกำหนดสิทธิ์
   หน้าที่:
   - สร้าง/ตรวจสอบ token (ลงลายเซ็นด้วย HMAC ไม่ต้องติดตั้งไลบรารีเพิ่ม)
   - attachUser     : อ่าน token จาก header แล้วใส่ req.user
   - requireAuth    : ต้องเข้าสู่ระบบก่อนจึงใช้งานได้
   - requireAdmin   : เฉพาะผู้ดูแลระบบเท่านั้น
   ========================================================================== */
const crypto = require('crypto');
const { TOKEN_SECRET, TOKEN_DAYS } = require('./config');
const db = require('./db');

const hmac = (p) => crypto.createHmac('sha256', TOKEN_SECRET).update(p).digest('base64url');

function sign(uid) {
  const payload = Buffer.from(JSON.stringify({ uid, exp: Date.now() + TOKEN_DAYS * 864e5 })).toString('base64url');
  return payload + '.' + hmac(payload);
}

function verify(token) {
  if (!token || !token.includes('.')) return null;
  const [p, s] = token.split('.');
  const expected = hmac(p);
  if (s.length !== expected.length || !crypto.timingSafeEqual(Buffer.from(s), Buffer.from(expected))) return null;
  try {
    const d = JSON.parse(Buffer.from(p, 'base64url').toString());
    return d.exp > Date.now() ? d : null;
  } catch {
    return null;
  }
}

function attachUser(req, res, next) {
  const h = req.headers.authorization || '';
  const d = verify(h.startsWith('Bearer ') ? h.slice(7) : '');
  req.user = d ? db.get().users.find((u) => u.id === d.uid) || null : null;
  next();
}

function requireAuth(req, res, next) {
  if (!req.user) return res.status(401).json({ message: 'กรุณาเข้าสู่ระบบก่อน' });
  next();
}

function requireAdmin(req, res, next) {
  if (!req.user) return res.status(401).json({ message: 'กรุณาเข้าสู่ระบบก่อน' });
  if (req.user.role !== 'admin') return res.status(403).json({ message: 'เฉพาะผู้ดูแลระบบเท่านั้น' });
  next();
}

function publicUser(u) {
  const { passwordHash, salt, ...rest } = u;
  return rest;
}

module.exports = { sign, verify, attachUser, requireAuth, requireAdmin, publicUser };
