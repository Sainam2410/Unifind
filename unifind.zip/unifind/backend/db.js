/* ==========================================================================
   backend/db.js — ฐานข้อมูลแบบไฟล์ JSON (ไม่ต้องใช้ SQL)
   หน้าที่:
   - โหลด/บันทึกข้อมูลทั้งหมดที่ไฟล์ data/db.json
   - สร้างข้อมูลตัวอย่างให้อัตโนมัติเมื่อรันครั้งแรก (ผู้ดูแล, ผู้ใช้, หมวดหมู่, รายการ)
   - มีฟังก์ชันเข้ารหัสรหัสผ่าน (scrypt) และตรวจสอบรหัสผ่าน
   อยากรีเซ็ตข้อมูลทั้งหมด: ลบไฟล์ data/db.json แล้วรันใหม่
   ========================================================================== */
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const { DB_FILE } = require('./config');

let data = null;

function hashPassword(pw, salt = crypto.randomBytes(16).toString('hex')) {
  const hash = crypto.scryptSync(pw, salt, 64).toString('hex');
  return { salt, hash };
}

function verifyPassword(pw, salt, hash) {
  const h = crypto.scryptSync(pw, salt, 64);
  const b = Buffer.from(hash, 'hex');
  return b.length === h.length && crypto.timingSafeEqual(h, b);
}

const ago = (n) => new Date(Date.now() - n * 864e5).toISOString();
const day = (n) => ago(n).slice(0, 10);

function seed() {
  const a = hashPassword('admin1234');
  const u = hashPassword('demo1234');
  const users = [
    { id: 1, name: 'ผู้ดูแลระบบ', email: 'admin@unifind.ac.th', studentId: '', phone: '', role: 'admin', salt: a.salt, passwordHash: a.hash, createdAt: ago(30) },
    { id: 2, name: 'สมชาย ใจดี', email: 'somchai@student.ac.th', studentId: '6501234567', phone: '081-234-5678', role: 'user', salt: u.salt, passwordHash: u.hash, createdAt: ago(20) },
  ];
  const categories = [
    { id: 1, name: 'กระเป๋า / กระเป๋าสตางค์', icon: '👜' },
    { id: 2, name: 'อุปกรณ์อิเล็กทรอนิกส์', icon: '📱' },
    { id: 3, name: 'บัตร / เอกสาร', icon: '🪪' },
    { id: 4, name: 'กุญแจ', icon: '🔑' },
    { id: 5, name: 'เสื้อผ้า / เครื่องแต่งกาย', icon: '🧥' },
    { id: 6, name: 'หนังสือ / เครื่องเขียน', icon: '📚' },
    { id: 7, name: 'ขวดน้ำ / กล่องข้าว', icon: '🍶' },
    { id: 8, name: 'อื่น ๆ', icon: '📦' },
  ];
  const mk = (id, type, title, categoryId, location, date, description, status, userId, n, contact) => ({
    id, type, title, description, categoryId, location, date, status, contact, userId,
    image: null, createdAt: ago(n), updatedAt: ago(n),
  });
  const items = [
    mk(1, 'found', 'กระเป๋าสตางค์สีน้ำตาล', 1, 'อาคารเรียนรวม 2 ชั้น 3', day(2), 'กระเป๋าสตางค์หนังสีน้ำตาล พบวางอยู่บนม้านั่งหน้าห้องเรียน มีบัตรหลายใบอยู่ด้านใน', 'pending', 1, 2, 'เจ้าหน้าที่ประชาสัมพันธ์ อาคารเรียนรวม 2'),
    mk(2, 'found', 'กระเป๋าเป้สีดำ', 1, 'โรงอาหารกลาง', day(3), 'กระเป๋าเป้สีดำ ไม่ทราบยี่ห้อ มีพวงกุญแจรูปหมีห้อยอยู่ที่ซิป', 'open', 1, 3, 'เจ้าหน้าที่ประชาสัมพันธ์ อาคารเรียนรวม 2'),
    mk(3, 'found', 'หูฟังไร้สาย (เคสสีขาว)', 2, 'ห้องสมุดกลาง', day(5), 'หูฟังไร้สายพร้อมเคสชาร์จสีขาว พบบนโต๊ะอ่านหนังสือชั้น 2', 'returned', 2, 5, 'ติดต่อเคาน์เตอร์ห้องสมุด'),
    mk(4, 'lost', 'บัตรนักศึกษา', 3, 'ห้องปฏิบัติการคอมพิวเตอร์', day(1), 'บัตรนักศึกษาชื่อ สมชาย ใจดี น่าจะทำหล่นไว้หลังเลิกเรียนปฏิบัติการ', 'open', 2, 1, 'โทร 081-234-5678'),
    mk(5, 'lost', 'กุญแจมอเตอร์ไซค์ พวงกุญแจสีแดง', 4, 'ลานจอดรถหลังอาคาร 3', day(4), 'กุญแจมอเตอร์ไซค์ยี่ห้อฮอนด้า มีพวงกุญแจผ้าสีแดงติดอยู่', 'open', 2, 4, 'โทร 081-234-5678'),
    mk(6, 'found', 'ขวดน้ำสแตนเลสสีม่วง', 7, 'สนามกีฬากลาง', day(6), 'ขวดน้ำสแตนเลสเก็บความเย็น สีม่วง มีสติกเกอร์รูปดาว', 'open', 1, 6, 'เจ้าหน้าที่ประชาสัมพันธ์ อาคารเรียนรวม 2'),
  ];
  const claims = [
    { id: 1, itemId: 1, userId: 2, proof: 'กระเป๋าสตางค์ของผมมีบัตรนักศึกษาและบัตรประชาชนชื่อสมชาย ใจดี อยู่ในช่องใส่บัตรด้านซ้าย', contact: '081-234-5678', status: 'pending', note: '', createdAt: ago(1), updatedAt: ago(1) },
  ];
  return { users, categories, items, claims };
}

function load() {
  if (!fs.existsSync(DB_FILE)) {
    fs.mkdirSync(path.dirname(DB_FILE), { recursive: true });
    data = seed();
    save();
  } else {
    data = JSON.parse(fs.readFileSync(DB_FILE, 'utf8'));
  }
  return data;
}

function save() {
  const tmp = DB_FILE + '.tmp';
  fs.writeFileSync(tmp, JSON.stringify(data, null, 2));
  fs.renameSync(tmp, DB_FILE); // เขียนทับแบบปลอดภัย ไฟล์ไม่พังถ้าเครื่องดับกลางคัน
}

const get = () => data;
const nextId = (list) => list.reduce((m, x) => Math.max(m, x.id), 0) + 1;

module.exports = { load, save, get, nextId, hashPassword, verifyPassword };
