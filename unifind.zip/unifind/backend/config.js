/* ==========================================================================
   backend/config.js — ค่าตั้งต้นของระบบ
   หน้าที่: รวมค่าที่อาจต้องปรับ เช่น พอร์ต, รหัสลับสำหรับ token, ที่เก็บฐานข้อมูล
   ========================================================================== */
const path = require('path');

module.exports = {
  PORT: process.env.PORT || 3000,
  // ⚠️ ถ้านำไปใช้งานจริง ให้เปลี่ยนรหัสลับนี้ (หรือตั้งผ่านตัวแปร TOKEN_SECRET)
  TOKEN_SECRET: process.env.TOKEN_SECRET || 'unifind-change-this-secret',
  TOKEN_DAYS: 7, // อายุการเข้าสู่ระบบ (วัน)
  DB_FILE: path.join(__dirname, '..', 'data', 'db.json'),
};
