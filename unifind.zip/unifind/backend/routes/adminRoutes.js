/* ==========================================================================
   backend/routes/adminRoutes.js — ส่วนของผู้ดูแลระบบ (ทุกเส้นทางต้องเป็นแอดมิน)
   - GET    /api/admin/dashboard        : ข้อมูลสรุปสำหรับหน้า Dashboard
   - POST   /api/admin/categories       : เพิ่มหมวดหมู่
   - PUT    /api/admin/categories/:id   : แก้ไขหมวดหมู่
   - DELETE /api/admin/categories/:id   : ลบหมวดหมู่ (ถ้าไม่มีรายการใช้อยู่)
   - GET    /api/admin/users            : รายชื่อผู้ใช้
   - PATCH  /api/admin/users/:id/role   : เปลี่ยนสิทธิ์ผู้ใช้ (user / admin)
   ========================================================================== */
const router = require('express').Router();
const db = require('../db');
const { requireAdmin, publicUser } = require('../auth');
const { itemView } = require('../views');

router.use(requireAdmin);

router.get('/dashboard', (req, res) => {
  const d = db.get();
  const items = d.items;

  // จำนวนรายการที่แจ้งในแต่ละวัน ย้อนหลัง 14 วัน
  const last14 = [];
  for (let i = 13; i >= 0; i--) {
    const date = new Date(Date.now() - i * 864e5).toISOString().slice(0, 10);
    last14.push({ date, count: items.filter((x) => x.createdAt.slice(0, 10) === date).length });
  }

  res.json({
    totals: {
      lost: items.filter((i) => i.type === 'lost').length,
      found: items.filter((i) => i.type === 'found').length,
      open: items.filter((i) => i.status === 'open').length,
      pendingItems: items.filter((i) => i.status === 'pending').length,
      returned: items.filter((i) => i.status === 'returned').length,
      pendingClaims: d.claims.filter((c) => c.status === 'pending').length,
      users: d.users.length,
      items: items.length,
    },
    byCategory: d.categories
      .map((c) => ({ id: c.id, name: c.name, icon: c.icon, count: items.filter((i) => i.categoryId === c.id).length }))
      .sort((a, b) => b.count - a.count),
    last14,
    recent: items.slice().sort((a, b) => b.createdAt.localeCompare(a.createdAt)).slice(0, 5).map((i) => itemView(i, req)),
  });
});

// ---------- หมวดหมู่ ----------
function readCategory(body) {
  const name = String(body.name || '').trim().slice(0, 40);
  const icon = String(body.icon || '').trim().slice(0, 4) || '📦';
  if (name.length < 2) return { error: 'กรุณากรอกชื่อหมวดหมู่ (อย่างน้อย 2 ตัวอักษร)' };
  return { name, icon };
}

router.post('/categories', (req, res) => {
  const r = readCategory(req.body);
  if (r.error) return res.status(400).json({ message: r.error });
  const d = db.get();
  if (d.categories.some((c) => c.name === r.name)) return res.status(409).json({ message: 'มีหมวดหมู่ชื่อนี้อยู่แล้ว' });
  const cat = { id: db.nextId(d.categories), name: r.name, icon: r.icon };
  d.categories.push(cat);
  db.save();
  res.status(201).json({ category: cat });
});

router.put('/categories/:id', (req, res) => {
  const d = db.get();
  const cat = d.categories.find((c) => c.id === Number(req.params.id));
  if (!cat) return res.status(404).json({ message: 'ไม่พบหมวดหมู่นี้' });
  const r = readCategory(req.body);
  if (r.error) return res.status(400).json({ message: r.error });
  if (d.categories.some((c) => c.id !== cat.id && c.name === r.name)) return res.status(409).json({ message: 'มีหมวดหมู่ชื่อนี้อยู่แล้ว' });
  cat.name = r.name;
  cat.icon = r.icon;
  db.save();
  res.json({ category: cat });
});

router.delete('/categories/:id', (req, res) => {
  const d = db.get();
  const id = Number(req.params.id);
  if (!d.categories.some((c) => c.id === id)) return res.status(404).json({ message: 'ไม่พบหมวดหมู่นี้' });
  if (d.items.some((i) => i.categoryId === id)) return res.status(400).json({ message: 'มีรายการใช้หมวดหมู่นี้อยู่ ไม่สามารถลบได้' });
  d.categories = d.categories.filter((c) => c.id !== id);
  db.save();
  res.json({ ok: true });
});

// ---------- ผู้ใช้ ----------
router.get('/users', (req, res) => {
  const d = db.get();
  const users = d.users.map((u) => ({
    ...publicUser(u),
    itemCount: d.items.filter((i) => i.userId === u.id).length,
  }));
  res.json({ users });
});

router.patch('/users/:id/role', (req, res) => {
  const d = db.get();
  const user = d.users.find((u) => u.id === Number(req.params.id));
  if (!user) return res.status(404).json({ message: 'ไม่พบผู้ใช้นี้' });
  if (user.id === req.user.id) return res.status(400).json({ message: 'ไม่สามารถเปลี่ยนสิทธิ์ของตัวเองได้' });
  if (!['user', 'admin'].includes(req.body.role)) return res.status(400).json({ message: 'สิทธิ์ไม่ถูกต้อง' });
  user.role = req.body.role;
  db.save();
  res.json({ user: publicUser(user) });
});

module.exports = router;
