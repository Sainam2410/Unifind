/* ==========================================================================
   backend/routes/itemRoutes.js — จัดการรายการของหาย / ของที่พบ
   - GET    /api/items              : ค้นหา + กรอง + แบ่งหน้า
   - GET    /api/items/:id          : รายละเอียดรายการ
   - GET    /api/items/:id/image    : รูปภาพของรายการ
   - POST   /api/items              : แจ้งของหาย / แจ้งพบของ (ต้องล็อกอิน)
   - PUT    /api/items/:id          : แก้ไข (เจ้าของหรือแอดมิน)
   - PATCH  /api/items/:id/status   : เปลี่ยนสถานะ (เจ้าของหรือแอดมิน)
   - DELETE /api/items/:id          : ลบ (เจ้าของหรือแอดมิน)
   - POST   /api/items/:id/claims   : ส่งคำขอรับคืน (ต้องล็อกอิน)
   ========================================================================== */
const router = require('express').Router();
const db = require('../db');
const { requireAuth } = require('../auth');
const { itemView } = require('../views');

const STATUSES = ['open', 'pending', 'returned'];
const clean = (s, max) => String(s ?? '').trim().slice(0, max);

// ตรวจสอบข้อมูลที่ส่งมาจากฟอร์ม
function validate(b) {
  const d = db.get();
  const v = {
    type: b.type,
    title: clean(b.title, 100),
    categoryId: Number(b.categoryId),
    location: clean(b.location, 120),
    date: clean(b.date, 10),
    description: clean(b.description, 1000),
    contact: clean(b.contact, 100),
  };
  if (!['lost', 'found'].includes(v.type)) return { error: 'กรุณาเลือกประเภทรายการ' };
  if (v.title.length < 2) return { error: 'กรุณากรอกชื่อสิ่งของ (อย่างน้อย 2 ตัวอักษร)' };
  if (!d.categories.some((c) => c.id === v.categoryId)) return { error: 'กรุณาเลือกหมวดหมู่' };
  if (v.location.length < 2) return { error: 'กรุณาระบุสถานที่' };
  if (!/^\d{4}-\d{2}-\d{2}$/.test(v.date) || isNaN(new Date(v.date))) return { error: 'กรุณาเลือกวันที่ให้ถูกต้อง' };
  if (new Date(v.date) > new Date(Date.now() + 864e5)) return { error: 'ไม่สามารถเลือกวันที่ในอนาคตได้' };
  if ('image' in b) {
    if (b.image === null) v.image = null;
    else if (typeof b.image === 'string' && /^data:image\/(png|jpe?g|webp|gif);base64,/.test(b.image) && b.image.length <= 2500000) v.image = b.image;
    else return { error: 'รูปภาพไม่ถูกต้องหรือมีขนาดใหญ่เกินไป' };
  }
  return { value: v };
}

router.get('/', (req, res) => {
  const d = db.get();
  const q = req.query;
  let list = d.items.slice();

  if (q.mine === '1') {
    if (!req.user) return res.status(401).json({ message: 'กรุณาเข้าสู่ระบบก่อน' });
    list = list.filter((i) => i.userId === req.user.id);
  }
  if (['lost', 'found'].includes(q.type)) list = list.filter((i) => i.type === q.type);
  if (q.category) list = list.filter((i) => i.categoryId === Number(q.category));
  if (STATUSES.includes(q.status)) list = list.filter((i) => i.status === q.status);
  if (q.location) {
    const l = String(q.location).trim().toLowerCase();
    if (l) list = list.filter((i) => i.location.toLowerCase().includes(l));
  }
  if (q.from) list = list.filter((i) => i.date >= q.from);
  if (q.to) list = list.filter((i) => i.date <= q.to);
  if (q.search) {
    const s = String(q.search).trim().toLowerCase();
    if (s) {
      list = list.filter((i) => {
        const cat = d.categories.find((c) => c.id === i.categoryId);
        return [i.title, i.description, i.location, cat && cat.name].join(' ').toLowerCase().includes(s);
      });
    }
  }

  list.sort((a, b) => b.createdAt.localeCompare(a.createdAt) || b.id - a.id);

  const pageSize = Math.min(Math.max(Number(q.pageSize) || 12, 1), 100);
  const total = list.length;
  const pages = Math.max(1, Math.ceil(total / pageSize));
  const page = Math.min(Math.max(Number(q.page) || 1, 1), pages);
  const items = list.slice((page - 1) * pageSize, page * pageSize).map((i) => itemView(i, req));
  res.json({ items, total, page, pages });
});

router.get('/:id/image', (req, res) => {
  const item = db.get().items.find((i) => i.id === Number(req.params.id));
  if (!item || !item.image) return res.status(404).end();
  const m = /^data:(image\/[\w+.-]+);base64,(.*)$/s.exec(item.image);
  if (!m) return res.status(404).end();
  res.set('Content-Type', m[1]);
  res.set('Cache-Control', 'public, max-age=86400');
  res.send(Buffer.from(m[2], 'base64'));
});

router.get('/:id', (req, res) => {
  const item = db.get().items.find((i) => i.id === Number(req.params.id));
  if (!item) return res.status(404).json({ message: 'ไม่พบรายการนี้' });
  res.json({ item: itemView(item, req, true) });
});

router.post('/', requireAuth, (req, res) => {
  const r = validate(req.body);
  if (r.error) return res.status(400).json({ message: r.error });
  const d = db.get();
  const now = new Date().toISOString();
  const item = { id: db.nextId(d.items), ...r.value, image: r.value.image || null, status: 'open', userId: req.user.id, createdAt: now, updatedAt: now };
  d.items.push(item);
  db.save();
  res.status(201).json({ item: itemView(item, req, true) });
});

function loadManageable(req, res) {
  const item = db.get().items.find((i) => i.id === Number(req.params.id));
  if (!item) { res.status(404).json({ message: 'ไม่พบรายการนี้' }); return null; }
  if (item.userId !== req.user.id && req.user.role !== 'admin') {
    res.status(403).json({ message: 'คุณไม่มีสิทธิ์จัดการรายการนี้' });
    return null;
  }
  return item;
}

router.put('/:id', requireAuth, (req, res) => {
  const item = loadManageable(req, res);
  if (!item) return;
  const r = validate(req.body);
  if (r.error) return res.status(400).json({ message: r.error });
  Object.assign(item, r.value, { updatedAt: new Date().toISOString() });
  db.save();
  res.json({ item: itemView(item, req, true) });
});

router.patch('/:id/status', requireAuth, (req, res) => {
  const item = loadManageable(req, res);
  if (!item) return;
  const status = req.body.status;
  const allowed = req.user.role === 'admin' ? STATUSES : ['open', 'returned'];
  if (!allowed.includes(status)) return res.status(400).json({ message: 'สถานะไม่ถูกต้อง' });
  item.status = status;
  item.updatedAt = new Date().toISOString();
  db.save();
  res.json({ item: itemView(item, req, true) });
});

router.delete('/:id', requireAuth, (req, res) => {
  const item = loadManageable(req, res);
  if (!item) return;
  const d = db.get();
  d.items = d.items.filter((i) => i.id !== item.id);
  d.claims = d.claims.filter((c) => c.itemId !== item.id);
  db.save();
  res.json({ ok: true });
});

// ส่งคำขอรับคืนสิ่งของที่มีผู้พบ
router.post('/:id/claims', requireAuth, (req, res) => {
  const d = db.get();
  const item = d.items.find((i) => i.id === Number(req.params.id));
  if (!item) return res.status(404).json({ message: 'ไม่พบรายการนี้' });
  if (item.type !== 'found') return res.status(400).json({ message: 'ส่งคำขอรับคืนได้เฉพาะรายการ "พบของ"' });
  if (item.status === 'returned') return res.status(400).json({ message: 'รายการนี้มีการรับคืนแล้ว' });
  if (item.userId === req.user.id) return res.status(400).json({ message: 'ไม่สามารถส่งคำขอรับคืนรายการของตัวเองได้' });
  if (d.claims.some((c) => c.itemId === item.id && c.userId === req.user.id && c.status === 'pending')) {
    return res.status(409).json({ message: 'คุณส่งคำขอรับคืนรายการนี้ไว้แล้ว กรุณารอการตรวจสอบ' });
  }
  const proof = clean(req.body.proof, 1000);
  const contact = clean(req.body.contact, 100);
  if (proof.length < 10) return res.status(400).json({ message: 'กรุณาอธิบายรายละเอียดที่ยืนยันความเป็นเจ้าของ (อย่างน้อย 10 ตัวอักษร)' });
  if (contact.length < 3) return res.status(400).json({ message: 'กรุณากรอกช่องทางติดต่อกลับ' });

  const now = new Date().toISOString();
  const claim = { id: db.nextId(d.claims), itemId: item.id, userId: req.user.id, proof, contact, status: 'pending', note: '', createdAt: now, updatedAt: now };
  d.claims.push(claim);
  item.status = 'pending';
  item.updatedAt = now;
  db.save();
  res.status(201).json({ claim });
});

module.exports = router;
