/* ==========================================================================
   backend/routes/authRoutes.js — สมัครสมาชิก / เข้าสู่ระบบ / โปรไฟล์
   - POST /api/auth/register : สมัครสมาชิกใหม่
   - POST /api/auth/login    : เข้าสู่ระบบ (ได้ token กลับไป)
   - GET  /api/auth/me       : ดูข้อมูลผู้ใช้ที่ล็อกอินอยู่
   - PUT  /api/auth/me       : แก้ไขโปรไฟล์ / เปลี่ยนรหัสผ่าน
   ========================================================================== */
const router = require('express').Router();
const db = require('../db');
const { sign, requireAuth, publicUser } = require('../auth');

const clean = (s, max) => String(s ?? '').trim().slice(0, max);
const emailRe = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

router.post('/register', (req, res) => {
  const name = clean(req.body.name, 60);
  const email = clean(req.body.email, 100).toLowerCase();
  const password = String(req.body.password || '');
  const studentId = clean(req.body.studentId, 20);
  const phone = clean(req.body.phone, 20);

  if (name.length < 2) return res.status(400).json({ message: 'กรุณากรอกชื่อ-นามสกุล' });
  if (!emailRe.test(email)) return res.status(400).json({ message: 'รูปแบบอีเมลไม่ถูกต้อง' });
  if (password.length < 6) return res.status(400).json({ message: 'รหัสผ่านต้องมีอย่างน้อย 6 ตัวอักษร' });

  const d = db.get();
  if (d.users.some((u) => u.email === email)) return res.status(409).json({ message: 'อีเมลนี้ถูกใช้งานแล้ว' });

  const { salt, hash } = db.hashPassword(password);
  const user = { id: db.nextId(d.users), name, email, studentId, phone, role: 'user', salt, passwordHash: hash, createdAt: new Date().toISOString() };
  d.users.push(user);
  db.save();
  res.status(201).json({ token: sign(user.id), user: publicUser(user) });
});

router.post('/login', (req, res) => {
  const email = clean(req.body.email, 100).toLowerCase();
  const password = String(req.body.password || '');
  const user = db.get().users.find((u) => u.email === email);
  if (!user || !db.verifyPassword(password, user.salt, user.passwordHash)) {
    return res.status(401).json({ message: 'อีเมลหรือรหัสผ่านไม่ถูกต้อง' });
  }
  res.json({ token: sign(user.id), user: publicUser(user) });
});

router.get('/me', requireAuth, (req, res) => res.json({ user: publicUser(req.user) }));

router.put('/me', requireAuth, (req, res) => {
  const u = req.user;
  const name = clean(req.body.name, 60);
  if (name.length < 2) return res.status(400).json({ message: 'กรุณากรอกชื่อ-นามสกุล' });
  u.name = name;
  u.studentId = clean(req.body.studentId, 20);
  u.phone = clean(req.body.phone, 20);

  if (req.body.newPassword) {
    if (!db.verifyPassword(String(req.body.currentPassword || ''), u.salt, u.passwordHash)) {
      return res.status(400).json({ message: 'รหัสผ่านปัจจุบันไม่ถูกต้อง' });
    }
    if (String(req.body.newPassword).length < 6) return res.status(400).json({ message: 'รหัสผ่านใหม่ต้องมีอย่างน้อย 6 ตัวอักษร' });
    const { salt, hash } = db.hashPassword(String(req.body.newPassword));
    u.salt = salt;
    u.passwordHash = hash;
  }
  db.save();
  res.json({ user: publicUser(u) });
});

module.exports = router;
