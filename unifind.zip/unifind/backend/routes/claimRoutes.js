/* ==========================================================================
   backend/routes/claimRoutes.js — คำขอรับคืนสิ่งของ
   - GET    /api/claims/mine      : คำขอที่ฉันส่งไป
   - GET    /api/claims/received  : คำขอที่ส่งมาที่รายการที่ฉันแจ้งพบ
   - GET    /api/claims           : คำขอทั้งหมด (แอดมิน)
   - PATCH  /api/claims/:id       : อนุมัติ / ไม่อนุมัติ (แอดมิน หรือผู้แจ้งพบสิ่งของนั้น)
   - DELETE /api/claims/:id       : ยกเลิกคำขอของตัวเอง (ที่ยังรอตรวจสอบ)
   ========================================================================== */
const router = require('express').Router();
const db = require('../db');
const { requireAuth, requireAdmin } = require('../auth');
const { claimView, syncItemStatus } = require('../views');

const newestFirst = (a, b) => b.createdAt.localeCompare(a.createdAt);

router.get('/mine', requireAuth, (req, res) => {
  const list = db.get().claims.filter((c) => c.userId === req.user.id).sort(newestFirst);
  res.json({ claims: list.map(claimView) });
});

router.get('/received', requireAuth, (req, res) => {
  const d = db.get();
  const myItemIds = d.items.filter((i) => i.userId === req.user.id).map((i) => i.id);
  const list = d.claims.filter((c) => myItemIds.includes(c.itemId)).sort(newestFirst);
  res.json({ claims: list.map(claimView) });
});

router.get('/', requireAdmin, (req, res) => {
  let list = db.get().claims.slice();
  if (['pending', 'approved', 'rejected'].includes(req.query.status)) list = list.filter((c) => c.status === req.query.status);
  list.sort(newestFirst);
  res.json({ claims: list.map(claimView) });
});

router.patch('/:id', requireAuth, (req, res) => {
  const d = db.get();
  const claim = d.claims.find((c) => c.id === Number(req.params.id));
  if (!claim) return res.status(404).json({ message: 'ไม่พบคำขอนี้' });
  const item = d.items.find((i) => i.id === claim.itemId);
  if (!item) return res.status(404).json({ message: 'ไม่พบรายการของคำขอนี้' });
  if (req.user.role !== 'admin' && item.userId !== req.user.id) {
    return res.status(403).json({ message: 'คุณไม่มีสิทธิ์ตรวจสอบคำขอนี้' });
  }
  if (claim.status !== 'pending') return res.status(400).json({ message: 'คำขอนี้ได้รับการตรวจสอบไปแล้ว' });

  const status = req.body.status;
  if (!['approved', 'rejected'].includes(status)) return res.status(400).json({ message: 'สถานะไม่ถูกต้อง' });

  const now = new Date().toISOString();
  claim.status = status;
  claim.note = String(req.body.note || '').trim().slice(0, 300);
  claim.updatedAt = now;

  if (status === 'approved') {
    item.status = 'returned';
    item.updatedAt = now;
    // คำขอรายอื่นของสิ่งของชิ้นเดียวกันถูกปฏิเสธอัตโนมัติ
    d.claims.forEach((c) => {
      if (c.itemId === item.id && c.id !== claim.id && c.status === 'pending') {
        c.status = 'rejected';
        c.note = 'สิ่งของนี้ได้รับการยืนยันผู้รับคืนแล้ว';
        c.updatedAt = now;
      }
    });
  } else {
    syncItemStatus(item);
  }
  db.save();
  res.json({ claim: claimView(claim) });
});

router.delete('/:id', requireAuth, (req, res) => {
  const d = db.get();
  const claim = d.claims.find((c) => c.id === Number(req.params.id));
  if (!claim) return res.status(404).json({ message: 'ไม่พบคำขอนี้' });
  if (claim.userId !== req.user.id) return res.status(403).json({ message: 'คุณไม่มีสิทธิ์ยกเลิกคำขอนี้' });
  if (claim.status !== 'pending') return res.status(400).json({ message: 'ยกเลิกได้เฉพาะคำขอที่ยังรอตรวจสอบ' });
  d.claims = d.claims.filter((c) => c.id !== claim.id);
  syncItemStatus(d.items.find((i) => i.id === claim.itemId));
  db.save();
  res.json({ ok: true });
});

module.exports = router;
