/* ==========================================================================
   backend/routes/publicRoutes.js — API ที่ทุกคนเรียกได้ (ไม่ต้องล็อกอิน)
   - GET /api/categories : รายการหมวดหมู่
   - GET /api/stats      : ตัวเลขสรุปสำหรับหน้าแรก
   ========================================================================== */
const router = require('express').Router();
const db = require('../db');

router.get('/categories', (req, res) => {
  res.json({ categories: db.get().categories });
});

router.get('/stats', (req, res) => {
  const items = db.get().items;
  res.json({
    lost: items.filter((i) => i.type === 'lost').length,
    found: items.filter((i) => i.type === 'found').length,
    open: items.filter((i) => i.status !== 'returned').length,
    returned: items.filter((i) => i.status === 'returned').length,
  });
});

module.exports = router;
