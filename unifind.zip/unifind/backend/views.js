/* ==========================================================================
   backend/views.js — ตัวช่วยแปลงข้อมูลดิบให้เป็นรูปแบบที่ส่งให้หน้าเว็บ
   หน้าที่:
   - itemView  : รวมชื่อหมวดหมู่ ชื่อผู้แจ้ง ลิงก์รูป และซ่อนข้อมูลติดต่อถ้ายังไม่ล็อกอิน
   - claimView : รวมชื่อรายการและชื่อผู้ขอรับคืน
   - syncItemStatus : ปรับสถานะรายการให้ตรงกับคำขอที่ค้างอยู่
   ========================================================================== */
const db = require('./db');

function itemView(item, req, detail = false) {
  const d = db.get();
  const cat = d.categories.find((c) => c.id === item.categoryId);
  const owner = d.users.find((u) => u.id === item.userId);
  const me = req.user;
  const isOwner = !!me && me.id === item.userId;
  const canManage = !!me && (isOwner || me.role === 'admin');
  const out = {
    id: item.id,
    type: item.type,
    title: item.title,
    description: item.description,
    categoryId: item.categoryId,
    categoryName: cat ? cat.name : 'อื่น ๆ',
    categoryIcon: cat ? cat.icon : '📦',
    location: item.location,
    date: item.date,
    status: item.status,
    createdAt: item.createdAt,
    updatedAt: item.updatedAt,
    reporterName: owner ? owner.name : 'ไม่ระบุ',
    imageUrl: item.image ? `/api/items/${item.id}/image?v=${encodeURIComponent(item.updatedAt)}` : null,
    isOwner,
    canManage,
  };
  if (me) out.contact = item.contact; // ข้อมูลติดต่อเห็นได้เฉพาะผู้ที่เข้าสู่ระบบ
  if (detail) {
    if (me) out.myClaim = d.claims.find((c) => c.itemId === item.id && c.userId === me.id) || null;
    if (canManage) out.claimCount = d.claims.filter((c) => c.itemId === item.id).length;
  }
  return out;
}

function claimView(c) {
  const d = db.get();
  const item = d.items.find((i) => i.id === c.itemId);
  const user = d.users.find((u) => u.id === c.userId);
  return {
    ...c,
    itemTitle: item ? item.title : '(รายการถูกลบแล้ว)',
    itemStatus: item ? item.status : null,
    itemType: item ? item.type : null,
    claimerName: user ? user.name : 'ไม่ระบุ',
    claimerEmail: user ? user.email : '',
    claimerStudentId: user ? user.studentId : '',
  };
}

function syncItemStatus(item) {
  if (!item || item.status === 'returned') return;
  const hasPending = db.get().claims.some((c) => c.itemId === item.id && c.status === 'pending');
  item.status = hasPending ? 'pending' : 'open';
  item.updatedAt = new Date().toISOString();
}

module.exports = { itemView, claimView, syncItemStatus };
